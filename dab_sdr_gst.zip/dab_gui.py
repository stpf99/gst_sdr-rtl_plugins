#!/usr/bin/env python3
"""Proste GUI: rtl_tcp → dabplus → audio, lista stacji z FIC (services-json)."""

import json
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gst", "1.0")
from gi.repository import Gtk, Gst, GLib

HOST = "192.168.1.1"
PORT = 1234
FREQ = 216_928_000
RATE = 2_048_000
GAIN = 0.0  # AGC (rtl_tcp)


class DabWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="DAB+ (dabplus)")
        self.set_default_size(460, 520)
        self.connect("destroy", self.on_quit)

        Gst.init(None)
        self.pipeline = None
        self.dabplus = None
        self._last_json = ""

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for m in ("top", "bottom", "start", "end"):
            getattr(vbox, f"set_margin_{m}")(10)
        self.add(vbox)

        self.lbl = Gtk.Label(label="Zatrzymane")
        self.lbl.set_line_wrap(True)
        vbox.pack_start(self.lbl, False, False, 0)

        self.lbl_ensemble = Gtk.Label(label="Ensemble: —")
        self.lbl_ensemble.set_xalign(0.0)
        vbox.pack_start(self.lbl_ensemble, False, False, 0)

        # subch, sid, name, active
        self.store = Gtk.ListStore(int, str, str, bool)
        self.tree = Gtk.TreeView(model=self.store)
        for i, title in enumerate(["SubCh", "SId", "Nazwa"]):
            col = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=i)
            col.set_expand(i == 2)
            self.tree.append_column(col)
        self.tree.connect("row-activated", self.on_row_activated)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.add(self.tree)
        vbox.pack_start(scroll, True, True, 0)

        h = Gtk.Box(spacing=6)
        self.btn_play = Gtk.Button(label="Start")
        self.btn_stop = Gtk.Button(label="Stop")
        self.btn_play.connect("clicked", self.on_start)
        self.btn_stop.connect("clicked", self.on_stop)
        h.pack_start(self.btn_play, True, True, 0)
        h.pack_start(self.btn_stop, True, True, 0)
        vbox.pack_start(h, False, False, 0)

        h2 = Gtk.Box(spacing=6)
        h2.pack_start(Gtk.Label(label="SubCh:"), False, False, 0)
        self.spin = Gtk.SpinButton.new_with_range(0, 63, 1)
        self.spin.set_value(1)
        h2.pack_start(self.spin, False, False, 0)
        btn_go = Gtk.Button(label="Przełącz")
        btn_go.connect(
            "clicked", lambda *_: self.set_subch(int(self.spin.get_value()))
        )
        h2.pack_start(btn_go, False, False, 0)
        vbox.pack_start(h2, False, False, 0)

        self.show_all()

    # ---- pipeline --------------------------------------------------------

    def build_pipeline(self, subch: int) -> bool:
        # auto-select=false: GUI steruje subchannel; scan=false → dekoduj audio
        desc = (
            f"sdrsrc mode=tcp host={HOST} port={PORT} "
            f"frequency={FREQ} sample-rate={RATE} gain={GAIN} ! "
            f"queue max-size-buffers=0 max-size-bytes=0 "
            f"max-size-time=500000000 leaky=downstream ! "
            f"dabplus name=dab auto-select=false subchannel={subch} "
            f"threads=4 ! "
            f"queue max-size-time=2000000000 leaky=downstream ! "
            f"autoaudiosink sync=false"
        )
        try:
            self.pipeline = Gst.parse_launch(desc)
        except GLib.Error as e:
            self.pipeline = None
            self.dabplus = None
            self.lbl.set_text(f"Błąd budowy potoku: {e.message}")
            return False

        self.dabplus = self.pipeline.get_by_name("dab")
        self._last_json = ""

        # Sygnał services-changed(string json) — gdy FIC dociąga etykiety
        try:
            self.dabplus.connect("services-changed", self.on_services_changed)
        except TypeError:
            pass  # starszy build bez sygnału

        bus = self.pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect("message", self.on_bus)
        return True

    def on_start(self, *_):
        if self.pipeline:
            return
        subch = int(self.spin.get_value())
        if not self.build_pipeline(subch):
            return
        self.pipeline.set_state(Gst.State.PLAYING)
        self.lbl.set_text(f"Odtwarzanie · SubCh {subch} (czekam na FIC…)")
        self.store.clear()
        self.lbl_ensemble.set_text("Ensemble: (synchronizacja…)")
        GLib.timeout_add(800, self.poll_status)

    def on_stop(self, *_):
        if not self.pipeline:
            return
        self.pipeline.set_state(Gst.State.NULL)
        self.pipeline = None
        self.dabplus = None
        self._last_json = ""
        self.lbl.set_text("Zatrzymane")

    # ---- lista stacji z dabplus ------------------------------------------

    def on_services_changed(self, _elem, json_str: str):
        """Callback z wątku GStreamer → przepnij na main loop GTK."""
        GLib.idle_add(self.apply_services_json, json_str)
        return None

    def apply_services_json(self, json_str: str) -> bool:
        if not json_str or json_str == self._last_json:
            return False
        self._last_json = json_str
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError as e:
            print("services-json parse error:", e, json_str[:200])
            return False

        ensemble = data.get("ensemble") or "—"
        self.lbl_ensemble.set_text(f"Ensemble: {ensemble.strip()}")

        services = data.get("services") or []
        # zachowaj zaznaczenie / sortuj po SubCh
        services = sorted(services, key=lambda s: int(s.get("subch", 0)))

        self.store.clear()
        active_path = None
        for i, svc in enumerate(services):
            subch = int(svc.get("subch", 0))
            sid = str(svc.get("sid", ""))
            label = str(svc.get("label", "")).strip() or "?"
            active = bool(svc.get("active", False))
            self.store.append([subch, sid, label, active])
            if active:
                active_path = Gtk.TreePath.new_from_indices([i])

        if active_path is not None:
            self.tree.get_selection().select_path(active_path)

        n = len(services)
        self.lbl.set_text(f"Lista: {n} stacji · ensemble „{ensemble.strip()}”")
        return False  # idle_add: nie powtarzaj

    def refresh_services_from_property(self):
        """Fallback: odczyt property services-json (gdy sygnał nie dojdzie)."""
        if not self.dabplus:
            return
        try:
            js = self.dabplus.get_property("services-json")
        except Exception:
            return
        if js:
            self.apply_services_json(js)

    def poll_status(self):
        if not self.pipeline or not self.dabplus:
            return False

        # dociągaj listę także przez property (FIG 1 co kilka sekund)
        self.refresh_services_from_property()

        active_subch = self.dabplus.get_property("subchannel")
        nsvc = self.dabplus.get_property("num-services")
        sync = self.dabplus.get_property("sync-level")

        if active_subch < 0:
            self.lbl.set_text(
                f"Szukanie… usługi={nsvc}  ofdm_frames={sync}"
            )
        else:
            name = "?"
            for row in self.store:
                if row[0] == active_subch:
                    name = row[2]
                    break
            self.lbl.set_text(
                f"{name} (SubCh {active_subch}) · usługi={nsvc} · frames={sync}"
            )
        return True

    # ---- przełączanie ----------------------------------------------------

    def set_subch(self, subch: int):
        self.spin.set_value(subch)
        if self.dabplus:
            self.dabplus.set_property("subchannel", subch)
            self.lbl.set_text(f"Przełączanie na SubCh {subch}…")
            print(f"switch → subchannel={subch}")

    def on_row_activated(self, tree, path, _col):
        model = tree.get_model()
        subch = model[path][0]
        if not self.pipeline:
            self.spin.set_value(subch)
            self.on_start()
        else:
            self.set_subch(subch)

    def on_bus(self, _bus, msg):
        t = msg.type
        if t == Gst.MessageType.ERROR:
            err, dbg = msg.parse_error()
            self.lbl.set_text(f"Błąd: {err.message}")
            print(dbg)
        elif t == Gst.MessageType.EOS:
            self.on_stop()
        return True

    def on_quit(self, *_):
        self.on_stop()
        Gtk.main_quit()


if __name__ == "__main__":
    DabWindow()
    Gtk.main()
