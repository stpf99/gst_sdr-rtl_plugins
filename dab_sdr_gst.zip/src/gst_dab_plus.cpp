/*
 * gst_dab_plus — open-source DAB / DAB+ GStreamer element
 *
 * Data path (williamyang98/DAB-Radio cores, no closed .so):
 *
 *   IQ float32 interleaved (I,Q) @ 2.048 MHz
 *        │
 *        ▼
 *   OFDM_Demod::Process(complex<float>)
 *        │  On_OFDM_Frame → soft bits (viterbi_bit_t)
 *        ▼
 *   BasicRadio::Process(soft bits)
 *        │  FIC → ensemble / service list
 *        │  MSC → Basic_Audio_Channel
 *        ▼
 *   OnAudioData(BasicAudioParams, PCM bytes)
 *        │
 *        ▼
 *   src pad: audio/x-raw  (S16LE, 1/2 ch, 24/32/48 kHz)
 *
 * Requires: ofdm_core, dab_core, basic_radio (DAB-Radio), fftw3f, faad, mpg123, fmt
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gst/gst.h>
#include <gst/base/gstbasetransform.h>
#include <gst/audio/audio.h>

#include <atomic>
#include <cmath>
#include <complex>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "ofdm/ofdm_demodulator.h"
#include "ofdm/dab_ofdm_params_ref.h"
#include "ofdm/dab_prs_ref.h"
#include "ofdm/dab_mapper_ref.h"
#include "basic_radio/basic_radio.h"
#include "basic_radio/basic_audio_channel.h"
#include "basic_radio/basic_dab_plus_channel.h"
#include "basic_radio/basic_dab_channel.h"
#include "dab/constants/dab_parameters.h"
#include "dab/database/dab_database.h"
#include "utility/span.h"
#include "viterbi_config.h"

GST_DEBUG_CATEGORY_STATIC (gst_dab_plus_debug);
#define GST_CAT_DEFAULT gst_dab_plus_debug

enum {
  PROP_0,
  PROP_CHANNEL,
  PROP_FREQUENCY,
  PROP_AUTO_SELECT,
  PROP_CURRENT_SID,
  PROP_SUBCHANNEL,
  PROP_ENSEMBLE_LABEL,
  PROP_NUM_SERVICES,
  PROP_SYNC_LEVEL,
  PROP_THREADS,
  PROP_SCAN,
  PROP_SERVICES_JSON
};

enum {
  SIGNAL_SERVICES_CHANGED,
  SIGNAL_SYNC_CHANGED,
  LAST_SIGNAL
};

static guint gst_dab_plus_signals[LAST_SIGNAL] = { 0 };

#define DEFAULT_AUTO_SELECT TRUE
#define DEFAULT_THREADS 0
#define DAB_SAMPLE_RATE 2048000

/* ---- element ---------------------------------------------------------- */

#define GST_TYPE_DAB_PLUS (gst_dab_plus_get_type ())
G_DECLARE_FINAL_TYPE (GstDabPlus, gst_dab_plus, GST, DAB_PLUS, GstElement)

struct _GstDabPlus {
  GstElement parent;

  GstPad *sinkpad;
  GstPad *srcpad;

  /* properties */
  gchar *channel;
  guint frequency;
  gboolean auto_select;
  guint current_sid;
  gint subchannel; /* active SubChId, -1 = auto/first preferred */
  gint threads;
  gboolean scan; /* TRUE = FIC-only scan, never auto-enable audio decode */

  /* decoder stack (C++) */
  void *stack; /* DabStack* */

  gboolean started;
  std::mutex *lock;
};

/* ---- C++ decoder stack ------------------------------------------------ */

struct DabStack {
  std::unique_ptr<OFDM_Demod> ofdm;
  std::unique_ptr<BasicRadio> radio;
  DAB_Parameters dab_params;
  OFDM_Params ofdm_params;

  std::vector<std::complex<float>> prs_ref;
  std::vector<int> mapper_ref;
  std::vector<std::complex<float>> iq_scratch;

  std::mutex audio_mu;
  std::vector<guint8> audio_queue;
  BasicAudioParams audio_params {};
  gboolean have_audio_params = FALSE;
  gboolean caps_pushed = FALSE;
  gboolean printed_services = FALSE; /* per-instance, not process-wide */
  gboolean stream_start_pushed = FALSE;
  guint64 audio_frames_pushed = 0; /* running sample count for PTS/DURATION */

  std::atomic<int> sync_hint { 0 }; /* frames read as proxy */
  std::string ensemble_label;
  guint selected_sid = 0;
  gboolean auto_select = TRUE;
  int enabled_subch = -1; /* only one MSC audio channel fully decoded */
  /* Full JSON of last emitted list. FIG type-1 labels arrive one-per-cycle
   * after the bare service list, so content (not only count) keeps changing
   * for many seconds after first sync. Re-emit until it stabilises. */
  std::string last_services_json;

  GstDabPlus *elem = nullptr;

  static std::string json_escape (const std::string &in) {
    std::string out;
    out.reserve (in.size () + 8);
    for (unsigned char c : in) {
      switch (c) {
        case '"': out += "\\\""; break;
        case '\\': out += "\\\\"; break;
        case '\n': out += "\\n"; break;
        case '\r': out += "\\r"; break;
        case '\t': out += "\\t"; break;
        default:
          if (c < 0x20) {
            char buf[8];
            g_snprintf (buf, sizeof (buf), "\\u%04x", c);
            out += buf;
          } else {
            out += (char) c;
          }
      }
    }
    return out;
  }

  /* NOTE: caller must already hold radio->GetMutex(). Machine-parseable
     twin of print_service_list(): one JSON object, ready for
     json.loads()/serde/etc. on the consumer side, no ad-hoc text parsing
     needed. Trailing whitespace in labels (fixed-width from FIC) is kept
     as-is; trim on the consumer side if unwanted. */
  std::string build_services_json () {
    std::string out = "{\"ensemble\":";
    if (!radio) {
      out += "null,\"services\":[]}";
      return out;
    }
    auto &db = radio->GetDatabase ();
    out += db.ensemble.label.empty ()
        ? std::string ("null")
        : ("\"" + json_escape (db.ensemble.label) + "\"");
    out += ",\"services\":[";
    bool first = true;
    for (const auto &svc : db.services) {
      const uint32_t sid = svc.id.get_unique_identifier ();
      for (const auto &comp : db.service_components) {
        if (!(comp.service_id == svc.id))
          continue;
        if (comp.audio_service_type == AudioServiceType::UNDEFINED)
          continue;
        if (!first)
          out += ",";
        first = false;
        char sidbuf[16];
        g_snprintf (sidbuf, sizeof (sidbuf), "0x%04X", sid);
        out += "{\"sid\":\"" + std::string (sidbuf) + "\",\"subch\":" +
            std::to_string ((unsigned) comp.subchannel_id) +
            ",\"label\":\"" + json_escape (svc.label) + "\",\"active\":" +
            (((int) comp.subchannel_id == enabled_subch) ? "true" : "false") +
            "}";
      }
    }
    out += "]}";
    return out;
  }

  void on_ofdm_frame (tcb::span<const viterbi_bit_t> bits) {
    if (radio)
      radio->Process (bits);
    sync_hint = ofdm ? ofdm->GetTotalFramesRead () : 0;
  }

  /* NOTE: caller must already hold radio->GetMutex(). Both call sites
     (periodic status in chain(), and on_audio_channel() via Notify()) run
     with the lock held already; re-locking here on a non-recursive
     std::mutex would deadlock the streaming thread. */
  void print_service_list () {
    if (!radio)
      return;
    auto &db = radio->GetDatabase ();
    g_printerr ("dabplus: === services (%zu) ensemble=\"%s\" ===\n",
        db.services.size (),
        db.ensemble.label.empty () ? "?" : db.ensemble.label.c_str ());
    for (const auto &svc : db.services) {
      const uint32_t sid = svc.id.get_unique_identifier ();
      for (const auto &comp : db.service_components) {
        if (!(comp.service_id == svc.id))
          continue;
        if (comp.audio_service_type == AudioServiceType::UNDEFINED)
          continue;
        g_printerr ("  SId=0x%04X  SubCh=%u  \"%s\"\n",
            sid, (unsigned) comp.subchannel_id,
            svc.label.empty () ? "?" : svc.label.c_str ());
      }
    }
    g_printerr ("dabplus: switch: dabplus subchannel=N   (N = SubCh above)\n");
  }

  /* NOTE: caller must already hold radio->GetMutex(), same as above. */
  std::string find_label_for_subchannel (subchannel_id_t subch) {
    if (!radio)
      return {};
    auto &db = radio->GetDatabase ();
    for (const auto &comp : db.service_components) {
      if (comp.subchannel_id != subch)
        continue;
      for (const auto &svc : db.services) {
        if (svc.id == comp.service_id)
          return svc.label.empty () ? std::string ("?") : svc.label;
      }
    }
    return {};
  }

  void switch_subchannel (int subch) {
    if (!radio || subch < 0)
      return;
    auto lock = std::scoped_lock (radio->GetMutex ());
    if (enabled_subch == subch)
      return;
    if (enabled_subch >= 0) {
      auto *old = radio->Get_Audio_Channel ((subchannel_id_t) enabled_subch);
      if (old)
        old->GetControls ().StopAll ();
    }
    auto *ch = radio->Get_Audio_Channel ((subchannel_id_t) subch);
    if (!ch) {
      g_printerr ("dabplus: subchannel %d not available yet\n", subch);
      return;
    }
    enabled_subch = subch;
    ch->GetControls ().RunAll ();
    attach_audio (*ch);
    /* reset audio caps so rate/channels renegotiate if needed */
    {
      std::lock_guard<std::mutex> g (audio_mu);
      audio_queue.clear ();
      have_audio_params = FALSE;
      caps_pushed = FALSE;
      audio_frames_pushed = 0;
    }
    g_printerr ("dabplus: switched to subch=%d\n", subch);
  }

  void attach_audio (Basic_Audio_Channel &ch) {
    ch.OnAudioData ().Attach (
        [this] (BasicAudioParams params, tcb::span<const uint8_t> buf) {
          std::lock_guard<std::mutex> g (audio_mu);
          if (!have_audio_params || audio_params != params) {
            audio_params = params;
            have_audio_params = TRUE;
          }
          audio_queue.insert (audio_queue.end (), buf.begin (), buf.end ());
        });
  }

  void on_audio_channel (subchannel_id_t id, Basic_Audio_Channel &ch) {
    if (elem && elem->scan) {
      /* Pure FIC scan: never decode MSC/audio, just let the service
         database build up. Keeps CPU low and avoids interfering with
         whatever the caller intends to do with the scan results. */
      ch.GetControls ().StopAll ();
      return;
    }
    /* Prefer SubChId 1 (often primary service, e.g. PR Jedynka).
       If another channel was enabled earlier, switch when id==1 appears. */
    /* Prefer explicit subchannel property, else SubCh 1, else first seen. */
    const int want = (elem && elem->subchannel >= 0) ? elem->subchannel : 1;
    const bool prefer = ((int) id == want) || (enabled_subch < 0 && (int) id == want)
                        || (enabled_subch < 0 && id == 1)
                        || (enabled_subch < 0);
    if (prefer && (int) id != enabled_subch) {
      if (enabled_subch >= 0 && radio) {
        auto *old = radio->Get_Audio_Channel ((subchannel_id_t) enabled_subch);
        if (old)
          old->GetControls ().StopAll ();
      }
      enabled_subch = (int) id;
      ch.GetControls ().RunAll ();
      attach_audio (ch);
      {
        const std::string label = find_label_for_subchannel (id);
        g_printerr ("dabplus: audio channel subch=%u ENABLED (decode+play) "
            "station=\"%s\"\n", (unsigned) id, label.empty () ? "?" : label.c_str ());
      }
    } else if ((int) id == enabled_subch) {
      ch.GetControls ().RunAll ();
      attach_audio (ch);
    } else {
      ch.GetControls ().StopAll ();
      g_printerr ("dabplus: audio channel subch=%u idle\n", (unsigned) id);
    }
  }

  void ensure_audio_channels_enabled () {
    if (!radio || enabled_subch < 0)
      return;
    auto lock = std::scoped_lock (radio->GetMutex ());
    auto *ch = radio->Get_Audio_Channel ((subchannel_id_t) enabled_subch);
    if (ch) {
      ch->GetControls ().RunAll ();
      /* surface decoder health - called every ~200 buffers on the
         streaming thread, so this MUST NOT be a blocking stderr write
         (g_printerr). GST_LOG_OBJECT is a no-op unless GST_DEBUG is set. */
      auto *dabp = dynamic_cast<Basic_DAB_Plus_Channel *> (ch);
      auto *dab = dynamic_cast<Basic_DAB_Channel *> (ch);
      if (dabp && elem) {
        GST_LOG_OBJECT (elem, "subch=%d firecode_err=%d rs_err=%d codec_err=%d",
            enabled_subch,
            (int) dabp->IsFirecodeError (),
            (int) dabp->IsRSError (),
            (int) dabp->IsCodecError ());
      } else if (dab && elem) {
        GST_LOG_OBJECT (elem, "subch=%d dab_mp2 err=%d",
            enabled_subch, (int) dab->GetIsError ());
      }
    }
  }

  void select_first_audio_service () {
    if (!radio || !auto_select || selected_sid != 0)
      return;
    auto &db = radio->GetDatabase ();
    for (const auto &svc : db.services) {
      const uint32_t sid = svc.id.get_unique_identifier ();
      if (sid == 0)
        continue;
      for (const auto &comp : db.service_components) {
        if (!(comp.service_id == svc.id))
          continue;
        if (comp.audio_service_type == AudioServiceType::UNDEFINED)
          continue;
        selected_sid = sid;
        if (elem) {
          GST_INFO_OBJECT (elem, "auto-select SId=0x%04x label=\"%s\"",
              sid, svc.label.c_str ());
        }
        return;
      }
    }
  }
};

static DabStack *
dab_stack_create (int transmission_mode, int nthreads, GstDabPlus *elem)
{
  auto *s = new DabStack ();
  s->elem = elem;
  s->dab_params = get_dab_parameters (transmission_mode);
  s->ofdm_params = get_DAB_OFDM_params (transmission_mode);

  s->prs_ref.resize (s->ofdm_params.nb_fft);
  get_DAB_PRS_reference (transmission_mode, s->prs_ref);
  s->mapper_ref.resize (s->ofdm_params.nb_data_carriers);
  get_DAB_mapper_ref (s->mapper_ref, s->ofdm_params.nb_fft);

  s->ofdm = std::make_unique<OFDM_Demod> (
      s->ofdm_params, tcb::span<const std::complex<float>> (s->prs_ref),
      tcb::span<const int> (s->mapper_ref), nthreads);

  /* RTL-SDR / rtl_tcp: noisier nulls — relax power-dip thresholds a bit */
  {
    auto &cfg = s->ofdm->GetConfig ();
    cfg.null_l1_search.thresh_null_start = 0.50f; /* was 0.35 */
    cfg.null_l1_search.thresh_null_end = 0.80f;   /* was 0.75 */
    cfg.signal_l1.update_beta = 0.90f;            /* adapt a bit faster */
    cfg.signal_l1.nb_samples = 50;                /* smaller blocks for short buffers */
    cfg.signal_l1.nb_decimate = 2;
  }

  s->ofdm->On_OFDM_Frame ().Attach (
      [s] (tcb::span<const viterbi_bit_t> bits) { s->on_ofdm_frame (bits); });

  s->radio = std::make_unique<BasicRadio> (s->dab_params, (size_t) nthreads);
  s->radio->On_Audio_Channel ().Attach (
      [s] (subchannel_id_t id, Basic_Audio_Channel &ch) {
        s->on_audio_channel (id, ch);
      });

  return s;
}

static void
dab_stack_destroy (DabStack *s)
{
  delete s;
}

/* ---- GStreamer boilerplate -------------------------------------------- */

G_DEFINE_TYPE (GstDabPlus, gst_dab_plus, GST_TYPE_ELEMENT)

static GstStaticPadTemplate sink_template = GST_STATIC_PAD_TEMPLATE ("sink",
    GST_PAD_SINK, GST_PAD_ALWAYS,
    GST_STATIC_CAPS (
        "application/x-raw, format=(string)F32LE, layout=(string)interleaved, "
        "channels=(int)2, rate=(int)2048000"));

static GstStaticPadTemplate src_template = GST_STATIC_PAD_TEMPLATE ("src",
    GST_PAD_SRC, GST_PAD_ALWAYS,
    GST_STATIC_CAPS (
        "audio/x-raw, format=(string)S16LE, layout=(string)interleaved, "
        "rate=(int){24000,32000,48000}, channels=(int){1,2}"));

static void gst_dab_plus_set_property (GObject *object, guint prop_id,
    const GValue *value, GParamSpec *pspec);
static void gst_dab_plus_get_property (GObject *object, guint prop_id,
    GValue *value, GParamSpec *pspec);
static void gst_dab_plus_finalize (GObject *object);
static GstStateChangeReturn gst_dab_plus_change_state (GstElement *element,
    GstStateChange transition);
static GstFlowReturn gst_dab_plus_chain (GstPad *pad, GstObject *parent,
    GstBuffer *buf);

static void
gst_dab_plus_class_init (GstDabPlusClass *klass)
{
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);
  GstElementClass *element_class = GST_ELEMENT_CLASS (klass);

  gobject_class->set_property = gst_dab_plus_set_property;
  gobject_class->get_property = gst_dab_plus_get_property;
  gobject_class->finalize = gst_dab_plus_finalize;
  element_class->change_state = gst_dab_plus_change_state;

  gst_element_class_set_static_metadata (element_class,
      "DAB/DAB+ receiver (open-source OFDM)",
      "Audio/Decoder/Receiver",
      "Demodulate DAB/DAB+ from 2.048 MS/s IQ using open OFDM + basic_radio",
      "gst-dab-open");

  gst_element_class_add_static_pad_template (element_class, &sink_template);
  gst_element_class_add_static_pad_template (element_class, &src_template);

  g_object_class_install_property (gobject_class, PROP_FREQUENCY,
      g_param_spec_uint ("frequency", "Frequency",
          "Centre frequency in Hz (e.g. 216928000 for 11A)",
          0, G_MAXUINT, 0,
          (GParamFlags) (G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_CHANNEL,
      g_param_spec_string ("channel", "Channel",
          "DAB channel label (informational, e.g. \"11A\")",
          NULL,
          (GParamFlags) (G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_AUTO_SELECT,
      g_param_spec_boolean ("auto-select", "Auto select",
          "Automatically select the first audio service",
          DEFAULT_AUTO_SELECT,
          (GParamFlags) (G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_CURRENT_SID,
      g_param_spec_uint ("current-sid", "Current SId",
          "Service ID to play (0 = none / auto)",
          0, G_MAXUINT, 0,
          (GParamFlags) (G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_THREADS,
      g_param_spec_int ("threads", "Threads",
          "OFDM/radio worker threads (0 = auto)",
          0, 64, DEFAULT_THREADS,
          (GParamFlags) (G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_SUBCHANNEL,
      g_param_spec_int ("subchannel", "Subchannel",
          "Active SubChId to decode/play (-1 = auto/first preferred)",
          -1, G_MAXINT, -1,
          (GParamFlags) (G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_NUM_SERVICES,
      g_param_spec_uint ("num-services", "Number of services",
          "Services in current ensemble",
          0, G_MAXUINT, 0,
          (GParamFlags) (G_PARAM_READABLE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_SYNC_LEVEL,
      g_param_spec_int ("sync-level", "Sync level",
          "Proxy: total OFDM frames decoded",
          0, G_MAXINT, 0,
          (GParamFlags) (G_PARAM_READABLE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_SCAN,
      g_param_spec_boolean ("scan", "Scan only",
          "FIC-only ensemble scan: build the service list but never "
          "auto-enable MSC/audio decode",
          FALSE,
          (GParamFlags) (G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS)));

  g_object_class_install_property (gobject_class, PROP_SERVICES_JSON,
      g_param_spec_string ("services-json", "Services (JSON)",
          "Current service list as JSON: "
          "{\"ensemble\":str|null,\"services\":"
          "[{\"sid\":\"0xXXXX\",\"subch\":N,\"label\":str,\"active\":bool}]}",
          "{\"ensemble\":null,\"services\":[]}",
          (GParamFlags) (G_PARAM_READABLE | G_PARAM_STATIC_STRINGS)));

  gst_dab_plus_signals[SIGNAL_SYNC_CHANGED] =
      g_signal_new ("sync-changed", G_TYPE_FROM_CLASS (klass),
          G_SIGNAL_RUN_LAST, 0, NULL, NULL, NULL,
          G_TYPE_NONE, 1, G_TYPE_INT);

  gst_dab_plus_signals[SIGNAL_SERVICES_CHANGED] =
      g_signal_new ("services-changed", G_TYPE_FROM_CLASS (klass),
          G_SIGNAL_RUN_LAST, 0, NULL, NULL, NULL,
          G_TYPE_NONE, 1, G_TYPE_STRING);
}

static void
gst_dab_plus_init (GstDabPlus *self)
{
  self->sinkpad = gst_pad_new_from_static_template (&sink_template, "sink");
  gst_pad_set_chain_function (self->sinkpad,
      GST_DEBUG_FUNCPTR (gst_dab_plus_chain));
  gst_element_add_pad (GST_ELEMENT (self), self->sinkpad);

  self->srcpad = gst_pad_new_from_static_template (&src_template, "src");
  gst_element_add_pad (GST_ELEMENT (self), self->srcpad);

  self->channel = NULL;
  self->frequency = 0;
  self->auto_select = DEFAULT_AUTO_SELECT;
  self->current_sid = 0;
  self->subchannel = -1;
  self->threads = DEFAULT_THREADS;
  self->scan = FALSE;
  self->stack = NULL;
  self->started = FALSE;
  self->lock = new std::mutex ();
}

static void
gst_dab_plus_finalize (GObject *object)
{
  GstDabPlus *self = GST_DAB_PLUS (object);
  g_free (self->channel);
  if (self->stack) {
    dab_stack_destroy ((DabStack *) self->stack);
    self->stack = NULL;
  }
  delete self->lock;
  G_OBJECT_CLASS (gst_dab_plus_parent_class)->finalize (object);
}

static void
gst_dab_plus_set_property (GObject *object, guint prop_id,
    const GValue *value, GParamSpec *pspec)
{
  GstDabPlus *self = GST_DAB_PLUS (object);
  switch (prop_id) {
    case PROP_FREQUENCY:
      self->frequency = g_value_get_uint (value);
      break;
    case PROP_CHANNEL:
      g_free (self->channel);
      self->channel = g_value_dup_string (value);
      break;
    case PROP_AUTO_SELECT:
      self->auto_select = g_value_get_boolean (value);
      if (self->stack)
        ((DabStack *) self->stack)->auto_select = self->auto_select;
      break;
    case PROP_CURRENT_SID:
      self->current_sid = g_value_get_uint (value);
      if (self->stack)
        ((DabStack *) self->stack)->selected_sid = self->current_sid;
      break;
    case PROP_SUBCHANNEL:
      self->subchannel = g_value_get_int (value);
      if (self->stack)
        ((DabStack *) self->stack)->switch_subchannel (self->subchannel);
      break;
    case PROP_THREADS:
      self->threads = g_value_get_int (value);
      break;
    case PROP_SCAN:
      self->scan = g_value_get_boolean (value);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
  }
}

static void
gst_dab_plus_get_property (GObject *object, guint prop_id,
    GValue *value, GParamSpec *pspec)
{
  GstDabPlus *self = GST_DAB_PLUS (object);
  DabStack *s = (DabStack *) self->stack;

  switch (prop_id) {
    case PROP_FREQUENCY:
      g_value_set_uint (value, self->frequency);
      break;
    case PROP_CHANNEL:
      g_value_set_string (value, self->channel);
      break;
    case PROP_AUTO_SELECT:
      g_value_set_boolean (value, self->auto_select);
      break;
    case PROP_CURRENT_SID:
      g_value_set_uint (value, self->current_sid);
      break;
    case PROP_SUBCHANNEL:
      g_value_set_int (value, self->subchannel >= 0 ? self->subchannel
          : (self->stack ? ((DabStack *) self->stack)->enabled_subch : -1));
      break;
    case PROP_THREADS:
      g_value_set_int (value, self->threads);
      break;
    case PROP_NUM_SERVICES:
      if (s && s->radio) {
        std::lock_guard<std::mutex> g (s->radio->GetMutex ());
        g_value_set_uint (value, (guint) s->radio->GetDatabase ().services.size ());
      } else {
        g_value_set_uint (value, 0);
      }
      break;
    case PROP_SYNC_LEVEL:
      g_value_set_int (value, s ? s->sync_hint.load () : 0);
      break;
    case PROP_SCAN:
      g_value_set_boolean (value, self->scan);
      break;
    case PROP_SERVICES_JSON:
      if (s && s->radio) {
        std::lock_guard<std::mutex> g (s->radio->GetMutex ());
        g_value_set_string (value, s->build_services_json ().c_str ());
      } else {
        g_value_set_string (value, "{\"ensemble\":null,\"services\":[]}");
      }
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
  }
}

static gboolean
gst_dab_plus_start (GstDabPlus *self)
{
  if (self->stack)
    return TRUE;

  /* transmission mode I (Band III) */
  DabStack *s = dab_stack_create (1, self->threads, self);
  s->auto_select = self->auto_select;
  s->selected_sid = self->current_sid;
  self->stack = s;
  self->started = TRUE;

  GST_INFO_OBJECT (self,
      "DAB stack started (open OFDM + basic_radio), freq=%u channel=%s threads=%d",
      self->frequency, self->channel ? self->channel : "(none)", self->threads);
  return TRUE;
}

static void
gst_dab_plus_stop (GstDabPlus *self)
{
  if (self->stack) {
    dab_stack_destroy ((DabStack *) self->stack);
    self->stack = NULL;
  }
  self->started = FALSE;
}

static GstStateChangeReturn
gst_dab_plus_change_state (GstElement *element, GstStateChange transition)
{
  GstDabPlus *self = GST_DAB_PLUS (element);
  GstStateChangeReturn ret;

  switch (transition) {
    case GST_STATE_CHANGE_NULL_TO_READY:
      break;
    case GST_STATE_CHANGE_READY_TO_PAUSED:
      if (!gst_dab_plus_start (self))
        return GST_STATE_CHANGE_FAILURE;
      break;
    default:
      break;
  }

  ret = GST_ELEMENT_CLASS (gst_dab_plus_parent_class)
            ->change_state (element, transition);
  if (ret == GST_STATE_CHANGE_FAILURE)
    return ret;

  switch (transition) {
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      gst_dab_plus_stop (self);
      break;
    default:
      break;
  }
  return ret;
}

/* push queued PCM to src pad */
static GstFlowReturn
gst_dab_plus_flush_audio (GstDabPlus *self)
{
  DabStack *s = (DabStack *) self->stack;
  if (!s)
    return GST_FLOW_OK;

  std::vector<guint8> chunk;
  BasicAudioParams params;
  {
    std::lock_guard<std::mutex> g (s->audio_mu);
    if (s->audio_queue.empty () || !s->have_audio_params)
      return GST_FLOW_OK;
    chunk.swap (s->audio_queue);
    params = s->audio_params;
  }

  if (!s->caps_pushed) {
    if (!s->stream_start_pushed) {
      gchar *stream_id =
          gst_pad_create_stream_id (self->srcpad, GST_ELEMENT (self), NULL);
      gst_pad_push_event (self->srcpad, gst_event_new_stream_start (stream_id));
      g_free (stream_id);
      s->stream_start_pushed = TRUE;
    }

    GstCaps *caps = gst_caps_new_simple ("audio/x-raw",
        "format", G_TYPE_STRING, "S16LE",
        "layout", G_TYPE_STRING, "interleaved",
        "rate", G_TYPE_INT, (gint) params.frequency,
        "channels", G_TYPE_INT, params.is_stereo ? 2 : 1,
        NULL);
    /* Push caps as an explicit sticky event (not gst_pad_set_caps(), which
       can defer the actual event dispatch) so it goes out via the exact
       same mechanism as the segment push below, guaranteeing caps arrives
       before segment downstream. */
    gst_pad_push_event (self->srcpad, gst_event_new_caps (caps));
    gst_caps_unref (caps);

    GstSegment seg;
    gst_segment_init (&seg, GST_FORMAT_TIME);
    gst_pad_push_event (self->srcpad, gst_event_new_segment (&seg));
    s->caps_pushed = TRUE;
    GST_INFO_OBJECT (self, "audio caps: %u Hz, %s",
        params.frequency, params.is_stereo ? "stereo" : "mono");
  }

  GstBuffer *out = gst_buffer_new_allocate (NULL, chunk.size (), NULL);
  GstMapInfo map;
  gst_buffer_map (out, &map, GST_MAP_WRITE);
  memcpy (map.data, chunk.data (), chunk.size ());
  gst_buffer_unmap (out, &map);

  /* S16LE interleaved: 2 bytes/sample * nb_channels per frame. Without a
     real PTS/DURATION here, downstream "queue max-size-time=..." can't
     compute its fill level (it stays 0) and falls back to the default
     200-buffer/10MB limit, which fills fast and starts leaky-dropping
     buffers -> periodic clicks/dropouts even though nothing is actually
     wrong upstream. Track a running sample count so timestamps are
     monotonic and continuous across pushes. */
  const guint bytes_per_frame = 2 * (params.is_stereo ? 2 : 1);
  const guint64 nb_frames = bytes_per_frame > 0
      ? (guint64) chunk.size () / bytes_per_frame : 0;
  GST_BUFFER_PTS (out) = gst_util_uint64_scale (
      s->audio_frames_pushed, GST_SECOND, (guint64) params.frequency);
  GST_BUFFER_DURATION (out) = gst_util_uint64_scale (
      nb_frames, GST_SECOND, (guint64) params.frequency);
  s->audio_frames_pushed += nb_frames;

  return gst_pad_push (self->srcpad, out);
}

static GstFlowReturn
gst_dab_plus_chain (GstPad *pad, GstObject *parent, GstBuffer *buf)
{
  GstDabPlus *self = GST_DAB_PLUS (parent);
  DabStack *s = (DabStack *) self->stack;
  GstMapInfo map;

  if (!s || !s->ofdm) {
    gst_buffer_unref (buf);
    return GST_FLOW_ERROR;
  }

  if (!gst_buffer_map (buf, &map, GST_MAP_READ)) {
    gst_buffer_unref (buf);
    return GST_FLOW_ERROR;
  }

  /* F32LE interleaved I,Q → complex<float> */
  const gsize n_floats = map.size / sizeof (float);
  const gsize n_pairs = n_floats / 2;
  s->iq_scratch.resize (n_pairs);
  const float *in = (const float *) map.data;
  double power_acc = 0.0;
  float peak = 0.0f;
  for (gsize i = 0; i < n_pairs; i++) {
    const float re = in[i * 2];
    const float im = in[i * 2 + 1];
    s->iq_scratch[i] = std::complex<float> (re, im);
    const float p = re * re + im * im;
    power_acc += (double) p;
    if (p > peak)
      peak = p;
  }

  gst_buffer_unmap (buf, &map);
  gst_buffer_unref (buf);

  s->ofdm->Process (tcb::span<const std::complex<float>> (s->iq_scratch));

  /* periodic diagnostics every ~200 buffers; logged via GST_INFO_OBJECT
     only (set GST_DEBUG=dabplus:4 to see it) - no unconditional stderr
     writes on the streaming thread, see note below. */
  static guint64 n;
  if ((++n % 200) == 0) {
    int frames = s->sync_hint.load ();
    guint nsvc = 0;
    guint audio_q = 0;
    {
      std::lock_guard<std::mutex> g (s->audio_mu);
      audio_q = (guint) s->audio_queue.size ();
    }
    guint naudio_ch = 0;
    guint naudio_comp = 0;
    std::string station_label;
    std::string json_to_emit;
    if (s->radio) {
      {
        std::lock_guard<std::mutex> g (s->radio->GetMutex ());
        nsvc = (guint) s->radio->GetDatabase ().services.size ();
        for (const auto &comp : s->radio->GetDatabase ().service_components) {
          if (comp.audio_service_type != AudioServiceType::UNDEFINED)
            naudio_comp++;
          if (s->radio->Get_Audio_Channel (comp.subchannel_id))
            naudio_ch++;
        }
        if (nsvc > 0) {
          if (!self->scan)
            s->select_first_audio_service ();
          /* Rebuild every tick: labels fill in gradually via FIG 1.
           * Emit/print only when the serialised content actually changes. */
          std::string cur_json = s->build_services_json ();
          if (cur_json != s->last_services_json) {
            s->last_services_json = cur_json;
            json_to_emit = std::move (cur_json);
            s->print_service_list ();
            s->printed_services = TRUE;
          }
        }
        if (s->enabled_subch >= 0) {
          station_label =
              s->find_label_for_subchannel ((subchannel_id_t) s->enabled_subch);
        }
      }
      s->ensure_audio_channels_enabled ();
    }
    const double rms = (n_pairs > 0) ? std::sqrt (power_acc / (double) n_pairs) : 0.0;
    const double peak_amp = std::sqrt ((double) peak);
    /* This fires every ~200 buffers on the streaming thread. g_printerr()
       here was a blocking stderr write on every tick, which is what was
       causing the periodic audio clicks - stderr I/O stalls the thread
       right in the middle of feeding the audio queue. Station name and
       service list are already announced once (on_audio_channel /
       print_service_list); the recurring diagnostics below only need to
       be visible with GST_DEBUG set, not printed unconditionally. */
    GST_INFO_OBJECT (self,
        "ofdm_frames=%d services=%u state=%d audio_q=%u audio_ch=%u "
        "audio_comp=%u iq_rms=%.5f peak=%.5f n=%zu station=\"%s\" subch=%d",
        frames, nsvc, (int) s->ofdm->GetState (), audio_q, naudio_ch,
        naudio_comp, rms, peak_amp, (size_t) n_pairs,
        station_label.empty () ? "?" : station_label.c_str (), s->enabled_subch);
    g_signal_emit (self, gst_dab_plus_signals[SIGNAL_SYNC_CHANGED], 0, frames);
    /* Emitted outside the radio lock: services-json is a self-contained
       string, cheap to pass by value through GObject's signal marshalling. */
    if (!json_to_emit.empty ())
      g_signal_emit (self, gst_dab_plus_signals[SIGNAL_SERVICES_CHANGED], 0,
          json_to_emit.c_str ());
  }

  return gst_dab_plus_flush_audio (self);
}

/* ---- plugin entry ----------------------------------------------------- */

static gboolean
plugin_init (GstPlugin *plugin)
{
  GST_DEBUG_CATEGORY_INIT (gst_dab_plus_debug, "dabplus", 0,
      "Open-source DAB/DAB+ receiver");
  return gst_element_register (plugin, "dabplus", GST_RANK_NONE, GST_TYPE_DAB_PLUS);
}

GST_PLUGIN_DEFINE (
    GST_VERSION_MAJOR,
    GST_VERSION_MINOR,
    dabplus,
    "Open-source DAB/DAB+ receiver (OFDM + basic_radio, no closed libs)",
    plugin_init,
    "0.1.0",
    "LGPL",
    "gst-dab-open",
    "https://github.com/williamyang98/DAB-Radio"
)
