# gst-dab-open — otwarty DAB/DAB+ dla GStreamera

Element **`dabplus`** dekoduje DAB/DAB+ z IQ **bez zamkniętych `.so`** (bez libdabsdr).

Źródła OFDM/DAB: [williamyang98/DAB-Radio](https://github.com/williamyang98/DAB-Radio) (MIT).

## Architektura

```
sdrsrc / rtl_tcp  →  IQ F32LE @ 2.048 MHz
                         │
                    dabplus
              ┌──────────┼──────────┐
              │ OFDM_Demod (ofdm_core)
              │   soft bits
              ▼
              BasicRadio (basic_radio + dab_core)
              │  FIC → ensemble + lista stacji (JSON)
              │  MSC → AAC (DAB+) / MP2 (DAB) → PCM S16LE
              ▼
         audio/x-raw  (24 / 32 / 48 kHz, mono/stereo)
```

## Zależności systemowe

```bash
# Ubuntu / Debian
sudo apt install \
  build-essential meson ninja-build pkg-config \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  libfftw3-dev libfmt-dev libfaad-dev libmpg123-dev

# GUI (opcjonalnie)
sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-3.0
```

AerynOS: odpowiedniki `fftw3f`, `fmt`, `faad2`, `mpg123`, GStreamer, Meson.

## Viterbi (header-only)

```bash
cd gst-dab-open
mkdir -p dab-radio/vendor
git clone --depth 1 \
  https://github.com/williamyang98/ViterbiDecoderCpp.git \
  dab-radio/vendor/viterbi_decoder
```

W `meson.build` w `include_directories` musi być:

```meson
'dab-radio/vendor/viterbi_decoder/include',
```

(biblioteki linkować nie trzeba — tylko nagłówki).

## Budowa

```bash
cd gst-dab-open
rm -rf builddir
meson setup builddir --prefix=/usr
ninja -C builddir
sudo ninja -C builddir install

# albo bez instalacji:
export GST_PLUGIN_PATH=$PWD/builddir
```

Jeśli kompilator zgłosi `no member named 'format' in namespace 'fmt'`:

```cpp
// w dab-radio/src/dab/audio/mp2_audio_decoder.cpp (i podobnych)
#include <fmt/format.h>
```

## Pipeline (odtwarzanie)

```bash
gst-launch-1.0 -v \
  sdrsrc mode=tcp host=192.168.1.1 port=1234 \
    frequency=216928000 sample-rate=2048000 gain=0 \
  ! queue max-size-buffers=0 max-size-bytes=0 max-size-time=500000000 leaky=downstream \
  ! dabplus channel=11A auto-select=true subchannel=-1 threads=2 \
  ! queue max-size-time=2000000000 leaky=downstream \
  ! autoaudiosink sync=false
```

Przełączanie stacji w locie (SubCh z listy FIC):

```text
g_object_set(dabplus, "subchannel", 3, NULL)   # np. PR Trójka
```

Samo skanowanie ensemble (bez dekodowania audio):

```bash
gst-launch-1.0 \
  sdrsrc mode=tcp host=192.168.1.1 port=1234 \
    frequency=216928000 sample-rate=2048000 gain=0 \
  ! dabplus scan=true \
  ! fakesink
# lista na stderr + property services-json
```

## Właściwości `dabplus`

| Właściwość | R/W | Opis |
|---|---|---|
| `frequency` | RW | Hz (informacyjnie; retune robi źródło) |
| `channel` | RW | np. `"11A"` |
| `auto-select` | RW | wybór pierwszej usługi audio |
| `current-sid` | RW | SId (0 = brak / auto) |
| **`subchannel`** | RW | aktywny **SubChId** (−1 = auto / preferowany) |
| `threads` | RW | wątki OFDM (0 = auto) |
| **`scan`** | RW | tylko FIC — bez MSC/audio |
| `num-services` | RO | liczba usług w ensemble |
| `sync-level` | RO | liczba zdekodowanych ramek OFDM |
| **`services-json`** | RO | lista stacji jako JSON (patrz niżej) |

## Sygnały

| Sygnał | Argumenty | Kiedy |
|---|---|---|
| `sync-changed` | `int` (frames) | okresowo przy postępie OFDM |
| **`services-changed`** | `string` (JSON) | **przy każdej zmianie treści listy** (także gdy FIG 1 dociąga etykiety) |

### Format `services-json`

```json
{
  "ensemble": "Polskie Radio ",
  "services": [
    {
      "sid": "0x3211",
      "subch": 1,
      "label": "PR Jedynka ",
      "active": true
    }
  ]
}
```

Etykiety (FIG type 1) przychodzą **stopniowo** — nie wszystkie naraz z listą SId. Plugin porównuje cały JSON i emituje `services-changed` / drukuje listę przy każdej zmianie, aż lista się ustabilizuje.

## GUI (`dab_gui.py`)

Proste GTK3:

- Start / Stop pipeline (`sdrsrc` → `dabplus` → `autoaudiosink`)
- Lista stacji z **`services-json`** + sygnału `services-changed` (bez hardkodu)
- Dwuklik / spin → `subchannel=N`

```bash
python3 dab_gui.py
```

Wymaga: `python3-gi`, GTK 3, zainstalowanego `dabplus` i `sdrsrc`.

## Debug

```bash
GST_DEBUG=dabplus:4 gst-launch-1.0 ... 2>&1 | tee /tmp/dab.log
```

Przydatne linie:

- `ofdm_frames=… state=…` — synchronizacja OFDM (`OFDM_Demod::GetState()`)
- `dabplus: === services (N) ensemble="…" ===` — lista z SubCh
- `audio channel subch=N ENABLED` — dekodowanie MSC

## Status

- Otwarty łańcuch OFDM → FIC/MSC → PCM, bez libdabsdr
- Przełączanie stacji po **SubChId**, JSON API, tryb `scan`
- GUI z żywą listą z FIC
- Zależności: fftw3f, faad2, mpg123, fmt, ViterbiDecoderCpp (header-only)

## Dlaczego nie libdabsdr

`libdabsdr` to zamknięta binarka AbracaDABra. Przy poprawnym IQ pull **zero** powiadomień sync — bez źródeł nie da się zdiagnozować skali / `count` / ABI. Otwarty OFDM loguje stan synchronizacji i listę usług z FIC.
