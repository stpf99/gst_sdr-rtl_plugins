import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class SdrRadioPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        
        let page = new Adw.PreferencesPage();
        let group = new Adw.PreferencesGroup({ title: 'Ustawienia RTL-SDR' });
        page.add(group);

        // Connection Mode
        let modeRow = new Adw.EntryRow({ title: 'Tryb połączenia (tcp lub local)' });
        group.add(modeRow);
        settings.bind('connection-mode', modeRow, 'text', Gio.SettingsBindFlags.DEFAULT);

        let hostRow = new Adw.EntryRow({ title: 'Host (dla TCP)' });
        group.add(hostRow);
        settings.bind('host', hostRow, 'text', Gio.SettingsBindFlags.DEFAULT);

        // Port Row z Gtk.Adjustment
        let portAdjustment = new Gtk.Adjustment({
            lower: 1,
            upper: 65535,
            step_increment: 1
        });
        let portRow = new Adw.SpinRow({
            title: 'Port',
            adjustment: portAdjustment
        });
        group.add(portRow);
        settings.bind('port', portRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        // Sample Rate Row z Gtk.Adjustment
        let srAdjustment = new Gtk.Adjustment({
            lower: 80000,
            upper: 3200000,
            step_increment: 1000
        });
        let srRow = new Adw.SpinRow({
            title: 'Sample Rate',
            adjustment: srAdjustment
        });
        group.add(srRow);
        settings.bind('sample-rate', srRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        // Gain Mode (używamy switcha zamiast comboboxa dla uproszczenia)
        let gainModeRow = new Adw.SwitchRow({ title: 'Automatyczny Gain' });
        group.add(gainModeRow);
        let isAuto = settings.get_string('gain-mode') === 'auto';
        gainModeRow.set_active(isAuto);
        gainModeRow.connect('notify::active', () => {
            settings.set_string('gain-mode', gainModeRow.get_active() ? 'auto' : 'manual');
        });

        // Gain Row z Gtk.Adjustment
        let gainAdjustment = new Gtk.Adjustment({
            lower: 0.0,
            upper: 50.0,
            step_increment: 0.1
        });
        let gainRow = new Adw.SpinRow({
            title: 'Gain (dla manual)',
            adjustment: gainAdjustment,
            digits: 1
        });
        group.add(gainRow);
        settings.bind('gain', gainRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        // Presets Group
        let presetsGroup = new Adw.PreferencesGroup({ title: 'Lista Stacji (Presets)' });
        page.add(presetsGroup);

        let presetsJson = settings.get_string('presets');
        let presets = [];
        try { presets = JSON.parse(presetsJson); } catch(e) {}

        let listBox = new Gtk.ListBox({ selection_mode: Gtk.SelectionMode.NONE });
        listBox.add_css_class('boxed-list');
        presetsGroup.add(listBox);

        let renderPresets = () => {
            listBox.remove_all();
            presets.forEach((preset, index) => {
                let row = new Adw.ActionRow({ title: preset.name, subtitle: `Freq: ${preset.freq} Hz | Demod: ${preset.demod}` });
                
                let delBtn = new Gtk.Button({ icon_name: 'user-trash-symbolic', valign: Gtk.Align.CENTER });
                delBtn.connect('clicked', () => {
                    presets.splice(index, 1);
                    settings.set_string('presets', JSON.stringify(presets));
                    renderPresets();
                });
                row.add_suffix(delBtn);
                listBox.append(row);
            });
        };
        renderPresets();

        // Add new preset row
        let addBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 5, margin_top: 10 });
        
        let nameEntry = new Gtk.Entry({ placeholder_text: 'Nazwa stacji', hexpand: true });
        let freqEntry = new Gtk.Entry({ placeholder_text: 'Częstotliwość (Hz)', hexpand: true });
        let demodCombo = new Gtk.DropDown({ model: new Gtk.StringList({ strings: ['fm', 'am'] }) });
        let addBtn = new Gtk.Button({ label: 'Dodaj', valign: Gtk.Align.CENTER });

        addBtn.connect('clicked', () => {
            let name = nameEntry.get_text();
            let freq = parseInt(freqEntry.get_text());
            let demod = demodCombo.get_selected() === 0 ? 'fm' : 'am';
            
            if (name && !isNaN(freq)) {
                presets.push({ name, freq, demod });
                settings.set_string('presets', JSON.stringify(presets));
                nameEntry.set_text('');
                freqEntry.set_text('');
                renderPresets();
            }
        });

        addBox.append(nameEntry);
        addBox.append(freqEntry);
        addBox.append(demodCombo);
        addBox.append(addBtn);
        presetsGroup.add(addBox);

        window.add(page);
    }
}
