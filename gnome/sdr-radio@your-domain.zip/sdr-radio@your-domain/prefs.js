import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class SdrRadioPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();

        // ========== PAGE 1: Połączenie i podstawowe ==========
        let page1 = new Adw.PreferencesPage({ title: 'Połączenie', icon_name: 'network-wireless-symbolic' });
        window.add(page1);

        let connGroup = new Adw.PreferencesGroup({ title: 'RTL-SDR / Połączenie' });
        page1.add(connGroup);

        let modeRow = new Adw.EntryRow({ title: 'Tryb połączenia (tcp lub local)' });
        connGroup.add(modeRow);
        settings.bind('connection-mode', modeRow, 'text', Gio.SettingsBindFlags.DEFAULT);

        let hostRow = new Adw.EntryRow({ title: 'Host (dla TCP)' });
        connGroup.add(hostRow);
        settings.bind('host', hostRow, 'text', Gio.SettingsBindFlags.DEFAULT);

        let portAdjustment = new Gtk.Adjustment({ lower: 1, upper: 65535, step_increment: 1 });
        let portRow = new Adw.SpinRow({ title: 'Port', adjustment: portAdjustment });
        connGroup.add(portRow);
        settings.bind('port', portRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        let srAdjustment = new Gtk.Adjustment({ lower: 80000, upper: 3200000, step_increment: 1000 });
        let srRow = new Adw.SpinRow({ title: 'Sample Rate', adjustment: srAdjustment });
        connGroup.add(srRow);
        settings.bind('sample-rate', srRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        let gainModeRow = new Adw.SwitchRow({ title: 'Automatyczny Gain' });
        connGroup.add(gainModeRow);
        let isAuto = settings.get_string('gain-mode') === 'auto';
        gainModeRow.set_active(isAuto);
        gainModeRow.connect('notify::active', () => {
            settings.set_string('gain-mode', gainModeRow.get_active() ? 'auto' : 'manual');
        });

        let gainAdjustment = new Gtk.Adjustment({ lower: 0.0, upper: 50.0, step_increment: 0.1 });
        let gainRow = new Adw.SpinRow({ title: 'Gain (dla manual)', adjustment: gainAdjustment, digits: 1 });
        connGroup.add(gainRow);
        settings.bind('gain', gainRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        // ========== PAGE 2: Demod / Audio defaults ==========
        let page2 = new Adw.PreferencesPage({ title: 'Demod / Audio', icon_name: 'audio-speakers-symbolic' });
        window.add(page2);

        let demodGroup = new Adw.PreferencesGroup({ title: 'Ustawienia domyślne demodulacji' });
        page2.add(demodGroup);

        let stereoRow = new Adw.SwitchRow({ title: 'Stereo domyślnie (dla FM)' });
        demodGroup.add(stereoRow);
        settings.bind('stereo-default', stereoRow, 'active', Gio.SettingsBindFlags.DEFAULT);

        let tauAdjustment = new Gtk.Adjustment({ lower: 10.0, upper: 100.0, step_increment: 1.0 });
        let tauRow = new Adw.SpinRow({
            title: 'Deemphasis τ (us) — 50 Europa, 75 USA',
            adjustment: tauAdjustment,
            digits: 1
        });
        demodGroup.add(tauRow);
        settings.bind('tau', tauRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        let maxDevAdjustment = new Gtk.Adjustment({ lower: 10000, upper: 150000, step_increment: 1000 });
        let maxDevRow = new Adw.SpinRow({ title: 'Max deviation (Hz)', adjustment: maxDevAdjustment });
        demodGroup.add(maxDevRow);
        settings.bind('max-deviation', maxDevRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        let cutoffAdjustment = new Gtk.Adjustment({ lower: 3000, upper: 20000, step_increment: 500 });
        let cutoffRow = new Adw.SpinRow({ title: 'Audio cutoff (Hz)', adjustment: cutoffAdjustment });
        demodGroup.add(cutoffRow);
        settings.bind('audio-cutoff', cutoffRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        let arAdjustment = new Gtk.Adjustment({ lower: 8000, upper: 96000, step_increment: 1000 });
        let arRow = new Adw.SpinRow({ title: 'Audio sample rate', adjustment: arAdjustment });
        demodGroup.add(arRow);
        settings.bind('audio-rate', arRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        let offsetAdjustment = new Gtk.Adjustment({ lower: -100000, upper: 100000, step_increment: 100 });
        let offsetRow = new Adw.SpinRow({ title: 'Frequency offset (Hz)', adjustment: offsetAdjustment, digits: 0 });
        demodGroup.add(offsetRow);
        settings.bind('freq-offset', offsetRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        // ========== PAGE 3: Odszumianie ==========
        let page3 = new Adw.PreferencesPage({ title: 'Odszumianie', icon_name: 'audio-volume-muted-symbolic' });
        window.add(page3);

        let denoiseGroup = new Adw.PreferencesGroup({ title: 'Ustawienia domyślne odszumiania' });
        page3.add(denoiseGroup);

        let denoiseEnRow = new Adw.SwitchRow({ title: 'Odszumianie włączone domyślnie' });
        denoiseGroup.add(denoiseEnRow);
        settings.bind('denoise-enabled', denoiseEnRow, 'active', Gio.SettingsBindFlags.DEFAULT);

        let thrAdjustment = new Gtk.Adjustment({ lower: 0.0, upper: 30.0, step_increment: 0.5 });
        let thrRow = new Adw.SpinRow({ title: 'Threshold (dB)', adjustment: thrAdjustment, digits: 1 });
        denoiseGroup.add(thrRow);
        settings.bind('denoise-threshold', thrRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        let aupAdjustment = new Gtk.Adjustment({ lower: 0.0001, upper: 0.5, step_increment: 0.001 });
        let aupRow = new Adw.SpinRow({ title: 'Alpha up', adjustment: aupAdjustment, digits: 4 });
        denoiseGroup.add(aupRow);
        settings.bind('denoise-alpha-up', aupRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        let adnAdjustment = new Gtk.Adjustment({ lower: 0.00001, upper: 0.1, step_increment: 0.0001 });
        let adnRow = new Adw.SpinRow({ title: 'Alpha down', adjustment: adnAdjustment, digits: 5 });
        denoiseGroup.add(adnRow);
        settings.bind('denoise-alpha-down', adnRow, 'value', Gio.SettingsBindFlags.DEFAULT);

        // Denoise presets management
        let denoisePresetsGroup = new Adw.PreferencesGroup({ title: 'Presety odszumiania' });
        page3.add(denoisePresetsGroup);

        let denoisePresetsJson = settings.get_string('denoise-presets');
        let denoisePresets = [];
        try { denoisePresets = JSON.parse(denoisePresetsJson); } catch (e) {}

        let dListBox = new Gtk.ListBox({ selection_mode: Gtk.SelectionMode.NONE });
        dListBox.add_css_class('boxed-list');
        denoisePresetsGroup.add(dListBox);

        let renderDenoisePresets = () => {
            dListBox.remove_all();
            denoisePresets.forEach((preset, index) => {
                let row = new Adw.ActionRow({
                    title: preset.name,
                    subtitle: `enabled=${preset.enabled} | thr=${preset.threshold} | α↑=${preset['alpha-up']} | α↓=${preset['alpha-down']}`
                });
                let delBtn = new Gtk.Button({ icon_name: 'user-trash-symbolic', valign: Gtk.Align.CENTER });
                delBtn.connect('clicked', () => {
                    denoisePresets.splice(index, 1);
                    settings.set_string('denoise-presets', JSON.stringify(denoisePresets));
                    renderDenoisePresets();
                });
                row.add_suffix(delBtn);
                dListBox.append(row);
            });
        };
        renderDenoisePresets();

        // Add denoise preset
        let dAddBox = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL, spacing: 6, margin_top: 10 });
        let dNameEntry = new Gtk.Entry({ placeholder_text: 'Nazwa presetu odszumiania', hexpand: true });
        let dEnSwitch = new Gtk.CheckButton({ label: 'Włączone', active: true });
        let dThrEntry = new Gtk.Entry({ placeholder_text: 'Threshold (np. 8.0)', hexpand: true });
        let dAupEntry = new Gtk.Entry({ placeholder_text: 'Alpha up (np. 0.01)', hexpand: true });
        let dAdnEntry = new Gtk.Entry({ placeholder_text: 'Alpha down (np. 0.0001)', hexpand: true });
        let dAddBtn = new Gtk.Button({ label: 'Dodaj / Zapisz preset', valign: Gtk.Align.CENTER });

        dAddBtn.connect('clicked', () => {
            let name = dNameEntry.get_text().trim();
            let thr = parseFloat(dThrEntry.get_text());
            let aup = parseFloat(dAupEntry.get_text());
            let adn = parseFloat(dAdnEntry.get_text());
            if (name && !isNaN(thr) && !isNaN(aup) && !isNaN(adn)) {
                let existing = denoisePresets.findIndex(p => p.name === name);
                let obj = {
                    name,
                    enabled: dEnSwitch.get_active(),
                    threshold: thr,
                    'alpha-up': aup,
                    'alpha-down': adn
                };
                if (existing >= 0) denoisePresets[existing] = obj;
                else denoisePresets.push(obj);
                settings.set_string('denoise-presets', JSON.stringify(denoisePresets));
                dNameEntry.set_text('');
                dThrEntry.set_text('');
                dAupEntry.set_text('');
                dAdnEntry.set_text('');
                renderDenoisePresets();
            }
        });

        dAddBox.append(dNameEntry);
        dAddBox.append(dEnSwitch);
        dAddBox.append(dThrEntry);
        dAddBox.append(dAupEntry);
        dAddBox.append(dAdnEntry);
        dAddBox.append(dAddBtn);
        denoisePresetsGroup.add(dAddBox);

        // ========== PAGE 4: Stacje ==========
        let page4 = new Adw.PreferencesPage({ title: 'Stacje', icon_name: 'radio-symbolic' });
        window.add(page4);

        let presetsGroup = new Adw.PreferencesGroup({ title: 'Lista stacji (Presets)' });
        page4.add(presetsGroup);

        let presetsJson = settings.get_string('presets');
        let presets = [];
        try { presets = JSON.parse(presetsJson); } catch (e) {}

        let listBox = new Gtk.ListBox({ selection_mode: Gtk.SelectionMode.NONE });
        listBox.add_css_class('boxed-list');
        presetsGroup.add(listBox);

        let renderPresets = () => {
            listBox.remove_all();
            presets.forEach((preset, index) => {
                let row = new Adw.ActionRow({
                    title: preset.name,
                    subtitle: `Freq: ${preset.freq} Hz | Demod: ${preset.demod}`
                });
                let delBtn = new Gtk.Button({ icon_name: 'user-trash-symbolic', valign: Gtk.Align.CENTER });
                delBtn.connect('clicked', () => {
                    presets.splice(index, 1);
                    settings.set_string('presets', JSON.stringify(presets));
                    renderPresets();
                });
                row.add_suffix(delBtn);
                listBox.append(row);
            });
        };
        renderPresets();

        let addBox = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 5, margin_top: 10 });
        let nameEntry = new Gtk.Entry({ placeholder_text: 'Nazwa stacji', hexpand: true });
        let freqEntry = new Gtk.Entry({ placeholder_text: 'Częstotliwość (Hz)', hexpand: true });
        let demodCombo = new Gtk.DropDown({ model: new Gtk.StringList({ strings: ['fm', 'am'] }) });
        let addBtn = new Gtk.Button({ label: 'Dodaj', valign: Gtk.Align.CENTER });

        addBtn.connect('clicked', () => {
            let name = nameEntry.get_text();
            let freq = parseInt(freqEntry.get_text());
            let demod = demodCombo.get_selected() === 0 ? 'fm' : 'am';
            if (name && !isNaN(freq)) {
                presets.push({ name, freq, demod });
                settings.set_string('presets', JSON.stringify(presets));
                nameEntry.set_text('');
                freqEntry.set_text('');
                renderPresets();
            }
        });

        addBox.append(nameEntry);
        addBox.append(freqEntry);
        addBox.append(demodCombo);
        addBox.append(addBtn);
        presetsGroup.add(addBox);

        // ========== PAGE 5: Powiadomienia ==========
        let page5 = new Adw.PreferencesPage({ title: 'Powiadomienia', icon_name: 'preferences-system-notifications-symbolic' });
        window.add(page5);

        let notifyGroup = new Adw.PreferencesGroup({ title: 'Powiadomienia systemowe (Main.notify)' });
        page5.add(notifyGroup);

        let nPlay = new Adw.SwitchRow({ title: 'Powiadamiaj o Play / Stop / Pause' });
        notifyGroup.add(nPlay);
        settings.bind('notify-play', nPlay, 'active', Gio.SettingsBindFlags.DEFAULT);

        let nRec = new Adw.SwitchRow({ title: 'Powiadamiaj o nagrywaniu' });
        notifyGroup.add(nRec);
        settings.bind('notify-record', nRec, 'active', Gio.SettingsBindFlags.DEFAULT);

        let nErr = new Adw.SwitchRow({ title: 'Powiadamiaj o błędach' });
        notifyGroup.add(nErr);
        settings.bind('notify-errors', nErr, 'active', Gio.SettingsBindFlags.DEFAULT);
    }
}
