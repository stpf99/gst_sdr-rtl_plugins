import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';
import Clutter from 'gi://Clutter';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

import {Extension, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const SDRIndicator = GObject.registerClass(
class SDRIndicator extends PanelMenu.Button {
    _init(settings, ext) {
        super._init(0.0, _('SDR Radio'), false);
        this._settings = settings;
        this._ext = ext;

        this._proc = null;
        this._procId = 0;          // unikalny id uruchomienia – chroni przed race
        this._isPaused = false;
        this._isRecording = false;
        this._currentPreset = null;
        this._restartPending = false;

        // Runtime overrides (sesja)
        this._stereo = settings.get_boolean('stereo-default');
        this._tau = settings.get_double('tau');
        this._denoiseEnabled = settings.get_boolean('denoise-enabled');
        this._denoiseThreshold = settings.get_double('denoise-threshold');
        this._denoiseAlphaUp = settings.get_double('denoise-alpha-up');
        this._denoiseAlphaDown = settings.get_double('denoise-alpha-down');
        this._currentDenoisePresetName = null;

        let icon = new St.Icon({ icon_name: 'audio-input-microphone-symbolic', style_class: 'system-status-icon' });
        this.add_child(icon);

        this._buildMenu();
    }

    _buildMenu() {
        this._statusLabel = new St.Label({ text: 'Stopped' });
        let statusItem = new PopupMenu.PopupBaseMenuItem({ reactive: false });
        statusItem.add_child(this._statusLabel);
        this.menu.addMenuItem(statusItem);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // ===== Station presets =====
        this._presetsSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._presetsSection);
        this._refreshPresets();

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // ===== Playback controls =====
        let playItem = new PopupMenu.PopupMenuItem(_('▶ Play'));
        playItem.connect('activate', () => this._play());
        this.menu.addMenuItem(playItem);

        this._pauseItem = new PopupMenu.PopupMenuItem(_('⏸ Pause'));
        this._pauseItem.connect('activate', () => this._togglePause());
        this.menu.addMenuItem(this._pauseItem);

        let stopItem = new PopupMenu.PopupMenuItem(_('⏹ Stop'));
        stopItem.connect('activate', () => this._stop(true));
        this.menu.addMenuItem(stopItem);

        let recItem = new PopupMenu.PopupMenuItem(_('⏺ Toggle Record'));
        recItem.connect('activate', () => this._toggleRecord());
        this.menu.addMenuItem(recItem);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // ===== Expandable: Deemphasis / Stereo =====
        this._audioSub = new PopupMenu.PopupSubMenuMenuItem(_('🎛 Demod / Stereo / Deemphasis'));
        this.menu.addMenuItem(this._audioSub);

        this._stereoItem = new PopupMenu.PopupSwitchMenuItem(_('Stereo (FM)'), this._stereo);
        this._stereoItem.connect('toggled', (item) => {
            this._stereo = item.state;
            if (this._settings.get_boolean('notify-play'))
                Main.notify('SDR Radio', `Stereo: ${this._stereo ? 'ON' : 'OFF (Mono)'}`);
            this._restartIfPlaying();
        });
        this._audioSub.menu.addMenuItem(this._stereoItem);

        let tau50 = new PopupMenu.PopupMenuItem(_('Deemphasis τ = 50 µs (Europa)'));
        tau50.connect('activate', () => {
            this._tau = 50.0;
            if (this._settings.get_boolean('notify-play'))
                Main.notify('SDR Radio', 'Deemphasis: 50 µs');
            this._restartIfPlaying();
        });
        this._audioSub.menu.addMenuItem(tau50);

        let tau75 = new PopupMenu.PopupMenuItem(_('Deemphasis τ = 75 µs (USA)'));
        tau75.connect('activate', () => {
            this._tau = 75.0;
            if (this._settings.get_boolean('notify-play'))
                Main.notify('SDR Radio', 'Deemphasis: 75 µs');
            this._restartIfPlaying();
        });
        this._audioSub.menu.addMenuItem(tau75);

        // ===== Expandable: Denoise =====
        this._denoiseSub = new PopupMenu.PopupSubMenuMenuItem(_('🔇 Odszumianie'));
        this.menu.addMenuItem(this._denoiseSub);

        this._denoiseSwitch = new PopupMenu.PopupSwitchMenuItem(_('Odszumianie włączone'), this._denoiseEnabled);
        this._denoiseSwitch.connect('toggled', (item) => {
            this._denoiseEnabled = item.state;
            if (this._settings.get_boolean('notify-play'))
                Main.notify('SDR Radio', `Odszumianie: ${this._denoiseEnabled ? 'ON' : 'OFF'}`);
            this._restartIfPlaying();
        });
        this._denoiseSub.menu.addMenuItem(this._denoiseSwitch);

        this._denoiseSub.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        this._denoisePresetsSection = new PopupMenu.PopupMenuSection();
        this._denoiseSub.menu.addMenuItem(this._denoisePresetsSection);
        this._refreshDenoisePresets();

        this._denoiseSub.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        let saveDefault = new PopupMenu.PopupMenuItem(_('💾 Zapisz bieżące jako "Sesja"'));
        saveDefault.connect('activate', () => this._saveCurrentDenoiseAs('Sesja'));
        this._denoiseSub.menu.addMenuItem(saveDefault);

        let saveManual = new PopupMenu.PopupMenuItem(_('💾 Zapisz bieżące jako "Manual"'));
        saveManual.connect('activate', () => this._saveCurrentDenoiseAs('Manual'));
        this._denoiseSub.menu.addMenuItem(saveManual);

        let thrHigh = new PopupMenu.PopupMenuItem(_('Threshold +2 dB (bardziej agresywne)'));
        thrHigh.connect('activate', () => {
            this._denoiseThreshold = Math.min(30, this._denoiseThreshold + 2);
            if (this._settings.get_boolean('notify-play'))
                Main.notify('SDR Radio', `Threshold: ${this._denoiseThreshold.toFixed(1)} dB`);
            this._restartIfPlaying();
        });
        this._denoiseSub.menu.addMenuItem(thrHigh);

        let thrLow = new PopupMenu.PopupMenuItem(_('Threshold −2 dB (delikatniejsze)'));
        thrLow.connect('activate', () => {
            this._denoiseThreshold = Math.max(0, this._denoiseThreshold - 2);
            if (this._settings.get_boolean('notify-play'))
                Main.notify('SDR Radio', `Threshold: ${this._denoiseThreshold.toFixed(1)} dB`);
            this._restartIfPlaying();
        });
        this._denoiseSub.menu.addMenuItem(thrLow);
    }

    _restartIfPlaying() {
        // Restart tylko gdy coś gra (lub jest w pauzie) – nie przy samym wyborze presetu stacji
        if (this._proc || this._isPaused || this._restartPending) {
            this._play();
        }
    }

    _saveCurrentDenoiseAs(name) {
        let presets = [];
        try { presets = JSON.parse(this._settings.get_string('denoise-presets')); } catch (e) {}
        let obj = {
            name,
            enabled: this._denoiseEnabled,
            threshold: this._denoiseThreshold,
            'alpha-up': this._denoiseAlphaUp,
            'alpha-down': this._denoiseAlphaDown
        };
        let idx = presets.findIndex(p => p.name === name);
        if (idx >= 0) presets[idx] = obj;
        else presets.push(obj);
        this._settings.set_string('denoise-presets', JSON.stringify(presets));
        this._currentDenoisePresetName = name;
        this._refreshDenoisePresets();
        if (this._settings.get_boolean('notify-play'))
            Main.notify('SDR Radio', `Zapisano preset odszumiania: ${name}`);
    }

    _refreshDenoisePresets() {
        this._denoisePresetsSection.removeAll();
        let presets = [];
        try { presets = JSON.parse(this._settings.get_string('denoise-presets')); } catch (e) {}

        presets.forEach(preset => {
            let label = `${preset.name} (thr=${preset.threshold}${preset.enabled ? '' : ' OFF'})`;
            let item = new PopupMenu.PopupMenuItem(label);
            item.connect('activate', () => {
                this._denoiseEnabled = !!preset.enabled;
                this._denoiseThreshold = preset.threshold;
                this._denoiseAlphaUp = preset['alpha-up'];
                this._denoiseAlphaDown = preset['alpha-down'];
                this._currentDenoisePresetName = preset.name;
                this._denoiseSwitch.setToggleState(this._denoiseEnabled);
                if (this._settings.get_boolean('notify-play'))
                    Main.notify('SDR Radio', `Odszumianie: ${preset.name}`);
                this._restartIfPlaying();
            });
            this._denoisePresetsSection.addMenuItem(item);
        });
    }

    _refreshPresets() {
        this._presetsSection.removeAll();
        let presetsJson = this._settings.get_string('presets');
        let presets = [];
        try { presets = JSON.parse(presetsJson); } catch (e) { presets = []; }

        presets.forEach(preset => {
            let item = new PopupMenu.PopupMenuItem(`${preset.name} (${(preset.freq / 1000000).toFixed(2)} MHz - ${preset.demod.toUpperCase()})`);
            item.connect('activate', () => {
                this._currentPreset = preset;
                this._statusLabel.set_text(`Selected: ${preset.name}`);
                this._play();
            });
            this._presetsSection.addMenuItem(item);
        });
    }

    _buildPipeline() {
        if (!this._currentPreset) {
            if (this._settings.get_boolean('notify-errors'))
                Main.notify('SDR Radio', 'Wybierz preset z listy!');
            return null;
        }

        let mode = this._settings.get_string('connection-mode');
        let host = this._settings.get_string('host');
        let port = this._settings.get_int('port');
        let sr = this._settings.get_int('sample-rate');
        let gainMode = this._settings.get_string('gain-mode');
        let gain = this._settings.get_double('gain');
        let freq = this._currentPreset.freq;
        let demod = this._currentPreset.demod;
        let stereo = (demod === 'fm') ? (this._stereo ? 'true' : 'false') : 'false';
        let maxDev = this._settings.get_int('max-deviation');
        let audioRate = this._settings.get_int('audio-rate');
        let audioCutoff = this._settings.get_int('audio-cutoff');
        let tau = this._tau;
        let freqOffset = this._settings.get_double('freq-offset');

        let cmd = `/usr/bin/gst-launch-1.0 -v sdrsrc mode=${mode}`;
        if (mode === 'tcp') cmd += ` host=${host} port=${port}`;
        cmd += ` frequency=${freq} sample-rate=${sr}`;
        if (gainMode === 'manual') cmd += ` gain=${gain}`;

        cmd += ` ! queue max-size-buffers=0 max-size-bytes=0 max-size-time=200000000 leaky=downstream`;
        cmd += ` ! sdrdemod mode=${demod} stereo=${stereo} max-deviation=${maxDev} audio-rate=${audioRate} audio-cutoff=${audioCutoff} tau=${tau} freq-offset=${freqOffset}`;
        cmd += ` ! audioconvert ! audioresample ! audio/x-raw,rate=${audioRate},channels=1`;

        if (this._denoiseEnabled) {
            cmd += ` ! sdrdenoise enabled=true threshold-db=${this._denoiseThreshold} alpha-up=${this._denoiseAlphaUp} alpha-down=${this._denoiseAlphaDown}`;
        } else {
            cmd += ` ! sdrdenoise enabled=false`;
        }
        cmd += ` ! queue max-size-buffers=0 max-size-bytes=0 max-size-time=1000000000`;

        if (this._isRecording) {
            let filepath = GLib.build_filenamev([GLib.get_home_dir(), `sdr_rec_${Date.now()}.wav`]);
            cmd += ` ! tee name=t t. ! queue ! autoaudiosink sync=false t. ! queue ! audioconvert ! wavenc ! filesink location="${filepath}"`;
            if (this._settings.get_boolean('notify-record'))
                Main.notify('SDR Radio', `Nagrywanie do: ${filepath}`);
        } else {
            cmd += ` ! autoaudiosink sync=false`;
        }

        console.log(`[SDR Radio] Wykonuję komendę: ${cmd}`);
        return cmd;
    }

    _readStderr(dataStream, myId) {
        dataStream.read_line_async(GLib.PRIORITY_DEFAULT, null, (stream, res) => {
            // Ignoruj stderr starych procesów
            if (this._procId !== myId) return;
            try {
                let [line] = stream.read_line_finish(res);
                if (line !== null) {
                    let str = imports.byteArray.toString(line);
                    console.error(`[SDR Radio] ${str}`);
                    this._readStderr(stream, myId);
                }
            } catch (e) {
                // stream zamknięty – normalne przy kill
            }
        });
    }

    _killProc() {
        if (!this._proc) return;
        try {
            // Najpierw łagodnie
            this._proc.send_signal(15); // SIGTERM
        } catch (e) {}
        try {
            // Na wszelki wypadek hard kill (proces może wisieć)
            let pid = this._proc.get_identifier();
            if (pid)
                GLib.spawn_command_line_async(`kill -9 ${pid}`);
        } catch (e) {}
        this._proc = null;
        this._isPaused = false;
    }

    _play() {
        // Zwiększ id – wszystkie stare callbacki będą ignorowane
        this._procId++;
        let myId = this._procId;

        this._killProc();
        this._isPaused = false;
        this._updatePauseLabel();

        let cmd = this._buildPipeline();
        if (!cmd) return;

        // Małe opóźnienie, żeby stary proces zdążył zwolnić urządzenie / port
        this._restartPending = true;
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 150, () => {
            // Jeśli w międzyczasie ktoś znowu kliknął – ten timeout jest już nieaktualny
            if (this._procId !== myId) {
                this._restartPending = false;
                return GLib.SOURCE_REMOVE;
            }

            try {
                let [success, argv] = GLib.shell_parse_argv(cmd);
                if (!success) {
                    console.error('[SDR Radio] Błąd parsowania komendy');
                    this._restartPending = false;
                    return GLib.SOURCE_REMOVE;
                }

                let proc = new Gio.Subprocess({
                    argv: argv,
                    flags: Gio.SubprocessFlags.STDERR_PIPE
                });
                proc.init(null);

                // Tylko jeśli nadal jesteśmy „aktualnym” uruchomieniem
                if (this._procId !== myId) {
                    try { proc.send_signal(15); } catch (e) {}
                    this._restartPending = false;
                    return GLib.SOURCE_REMOVE;
                }

                this._proc = proc;
                this._restartPending = false;

                let stderrPipe = proc.get_stderr_pipe();
                let dataStream = Gio.DataInputStream.new(stderrPipe);
                this._readStderr(dataStream, myId);

                proc.wait_async(null, (p, res) => {
                    try {
                        let ok = p.wait_finish(res);
                        // Tylko jeśli to nadal ten sam „sesyjny” proces
                        if (this._procId === myId && this._proc === p) {
                            this._proc = null;
                            this._isPaused = false;
                            this._updatePauseLabel();
                            if (!ok) {
                                this._statusLabel.set_text('Error!');
                                if (this._settings.get_boolean('notify-errors'))
                                    Main.notify('SDR Radio BŁĄD', 'Proces zakończony błędem. Sprawdź logi: journalctl --user -b | grep SDR');
                            } else {
                                this._statusLabel.set_text('Stopped');
                            }
                        }
                    } catch (e) {}
                });

                this._statusLabel.set_text(`Playing: ${this._currentPreset.name}`);
                if (this._settings.get_boolean('notify-play'))
                    Main.notify('SDR Radio', `Playing: ${this._currentPreset.name}`);
            } catch (e) {
                this._restartPending = false;
                if (this._settings.get_boolean('notify-errors'))
                    Main.notify('SDR Radio Error', e.message);
                console.error('[SDR Radio] Wyjątek: ' + e);
            }
            return GLib.SOURCE_REMOVE;
        });
    }

    _togglePause() {
        if (!this._proc && !this._isPaused) return;

        try {
            let pid = this._proc ? this._proc.get_identifier() : null;
            if (!pid) return;

            if (this._isPaused) {
                GLib.spawn_command_line_sync(`kill -CONT ${pid}`);
                this._isPaused = false;
                this._statusLabel.set_text(`Playing: ${this._currentPreset ? this._currentPreset.name : ''}`);
                if (this._settings.get_boolean('notify-play'))
                    Main.notify('SDR Radio', 'Resumed');
            } else {
                GLib.spawn_command_line_sync(`kill -STOP ${pid}`);
                this._isPaused = true;
                this._statusLabel.set_text(`Paused: ${this._currentPreset ? this._currentPreset.name : ''}`);
                if (this._settings.get_boolean('notify-play'))
                    Main.notify('SDR Radio', 'Paused');
            }
            this._updatePauseLabel();
        } catch (e) {
            if (this._settings.get_boolean('notify-errors'))
                Main.notify('SDR Radio', 'Błąd pauzy: ' + e.message);
        }
    }

    _updatePauseLabel() {
        if (this._pauseItem)
            this._pauseItem.label.text = this._isPaused ? _('▶ Resume') : _('⏸ Pause');
    }

    _stop(notify = true) {
        this._procId++;          // unieważnia stare callbacki i timeouty
        this._killProc();
        this._isPaused = false;
        this._updatePauseLabel();
        this._statusLabel.set_text('Stopped');
        if (notify && this._settings.get_boolean('notify-play'))
            Main.notify('SDR Radio', 'Stopped');
    }

    _toggleRecord() {
        this._isRecording = !this._isRecording;
        if (this._settings.get_boolean('notify-record'))
            Main.notify('SDR Radio', `Nagrywanie: ${this._isRecording ? 'Włączone' : 'Wyłączone'}`);
        this._restartIfPlaying();
    }

    destroy() {
        this._stop(false);
        super.destroy();
    }
});

export default class SdrRadioExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._indicator = new SDRIndicator(this._settings, this);
        Main.panel.addToStatusArea(this.uuid, this._indicator);

        this._settings.connect('changed::presets', () => {
            if (this._indicator) this._indicator._refreshPresets();
        });
        this._settings.connect('changed::denoise-presets', () => {
            if (this._indicator) this._indicator._refreshDenoisePresets();
        });
    }

    disable() {
        if (this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }
        this._settings = null;
    }
}
