import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';
import Clutter from 'gi://Clutter';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

import {Extension, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const SDRIndicator = GObject.registerClass(
class SDRIndicator extends PanelMenu.Button {
    _init(settings, ext) {
        super._init(0.0, _('SDR Radio'), false);
        this._settings = settings;
        this._ext = ext;
        
        this._proc = null;
        this._isRecording = false;
        this._currentPreset = null;

        let icon = new St.Icon({ icon_name: 'audio-input-microphone-symbolic', style_class: 'system-status-icon' });
        this.add_child(icon);

        this._buildMenu();
    }

    _buildMenu() {
        this._statusLabel = new St.Label({ text: 'Stopped' });
        let statusItem = new PopupMenu.PopupBaseMenuItem({ reactive: false });
        statusItem.add_child(this._statusLabel);
        this.menu.addMenuItem(statusItem);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        this._presetsSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._presetsSection);
        
        this._refreshPresets();

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        let playItem = new PopupMenu.PopupMenuItem(_('▶ Play'));
        playItem.connect('activate', () => this._play());
        this.menu.addMenuItem(playItem);

        let pauseItem = new PopupMenu.PopupMenuItem(_('⏸ Pause/Resume'));
        pauseItem.connect('activate', () => this._pause());
        this.menu.addMenuItem(pauseItem);

        let stopItem = new PopupMenu.PopupMenuItem(_('⏹ Stop'));
        stopItem.connect('activate', () => this._stop());
        this.menu.addMenuItem(stopItem);

        let recItem = new PopupMenu.PopupMenuItem(_('⏺ Toggle Record'));
        recItem.connect('activate', () => this._toggleRecord());
        this.menu.addMenuItem(recItem);
    }

    _refreshPresets() {
        this._presetsSection.removeAll();
        let presetsJson = this._settings.get_string('presets');
        let presets = [];
        try { presets = JSON.parse(presetsJson); } catch(e) { presets = []; }

        presets.forEach(preset => {
            let item = new PopupMenu.PopupMenuItem(`${preset.name} (${(preset.freq/1000000).toFixed(2)} MHz - ${preset.demod.toUpperCase()})`);
            item.connect('activate', () => {
                this._currentPreset = preset;
                this._statusLabel.set_text(`Selected: ${preset.name}`);
                this._play();
            });
            this._presetsSection.addMenuItem(item);
        });
    }

    _buildPipeline() {
        if (!this._currentPreset) {
            Main.notify("SDR Radio", "Wybierz preset z listy!");
            return null;
        }

        let mode = this._settings.get_string('connection-mode');
        let host = this._settings.get_string('host');
        let port = this._settings.get_int('port');
        let sr = this._settings.get_int('sample-rate');
        let gainMode = this._settings.get_string('gain-mode');
        let gain = this._settings.get_double('gain');
        let freq = this._currentPreset.freq;
        let demod = this._currentPreset.demod; // fm or am
        let stereo = (demod === 'fm') ? 'true' : 'false';

        // Używamy pełnej ścieżki do gst-launch-1.0, aby uniknąć problemów z PATH w GNOME
        let cmd = `/usr/bin/gst-launch-1.0 -v sdrsrc mode=${mode}`;
        if (mode === 'tcp') cmd += ` host=${host} port=${port}`;
        cmd += ` frequency=${freq} sample-rate=${sr}`;
        if (gainMode === 'manual') cmd += ` gain=${gain}`;

        cmd += ` ! queue max-size-buffers=0 max-size-bytes=0 max-size-time=200000000 leaky=downstream`;
        cmd += ` ! sdrdemod mode=${demod} stereo=${stereo} max-deviation=75000 audio-rate=48000 audio-cutoff=15000 tau=50 freq-offset=0`;
        cmd += ` ! audioconvert ! audioresample ! audio/x-raw,rate=48000,channels=1`;
        cmd += ` ! sdrdenoise enabled=true threshold-db=8 alpha-up=0.01 alpha-down=0.0001`;
        cmd += ` ! queue max-size-buffers=0 max-size-bytes=0 max-size-time=1000000000`;

        if (this._isRecording) {
            let filepath = GLib.build_filenamev([GLib.get_home_dir(), `sdr_rec_${Date.now()}.wav`]);
            cmd += ` ! tee name=t t. ! queue ! autoaudiosink sync=false t. ! queue ! audioconvert ! wavenc ! filesink location="${filepath}"`;
            Main.notify("SDR Radio", `Nagrywanie do: ${filepath}`);
        } else {
            cmd += ` ! autoaudiosink sync=false`;
        }

        console.log(`[SDR Radio] Wykonuję komendę: ${cmd}`);
        return cmd;
    }

    _readStderr(dataStream) {
        dataStream.read_line_async(GLib.PRIORITY_DEFAULT, null, (stream, res) => {
            try {
                let [line] = stream.read_line_finish(res);
                if (line !== null) {
                    let str = imports.byteArray.toString(line);
                    console.error(`[SDR Radio] ${str}`);
                    this._readStderr(stream);
                }
            } catch(e) {
                console.error("[SDR Radio] Błąd odczytu stderr: " + e);
            }
        });
    }

    _play() {
        this._stop();
        
        let cmd = this._buildPipeline();
        if (!cmd) return;

        try {
            let [success, argv] = GLib.shell_parse_argv(cmd);
            if (!success) {
                console.error("[SDR Radio] Błąd parsowania komendy");
                return;
            }

            this._proc = new Gio.Subprocess({
                argv: argv,
                flags: Gio.SubprocessFlags.STDERR_PIPE
            });
            this._proc.init(null);

            let stderrPipe = this._proc.get_stderr_pipe();
            let dataStream = Gio.DataInputStream.new(stderrPipe);
            this._readStderr(dataStream);

            this._proc.wait_async(null, (proc, res) => {
                try {
                    let success = proc.wait_finish(res);
                    if (this._proc !== null) {
                        this._proc = null;
                        if (!success) {
                            this._statusLabel.set_text('Error!');
                            Main.notify("SDR Radio BŁĄD", "Proces zakończony błędem. Sprawdź logi: journalctl --user -b | grep SDR");
                        } else {
                            this._statusLabel.set_text('Stopped');
                        }
                    }
                } catch (e) {}
            });

            this._statusLabel.set_text(`Playing: ${this._currentPreset.name}`);
        } catch (e) {
            Main.notify("SDR Radio Error", e.message);
            console.error("[SDR Radio] Wyjątek: " + e);
        }
    }

    _pause() {
        if (!this._proc) return;
        try {
            GLib.spawn_command_line_sync(`kill -STOP ${this._proc.get_identifier()}`);
            this._statusLabel.set_text(`Paused: ${this._currentPreset.name}`);
        } catch (e) {
            Main.notify("SDR Radio", "Błąd pauzowania: " + e.message);
        }
    }

    _stop() {
        if (this._proc) {
            this._proc.send_signal(15); // SIGTERM
            this._proc = null;
        }
        this._statusLabel.set_text('Stopped');
    }

    _toggleRecord() {
        this._isRecording = !this._isRecording;
        Main.notify("SDR Radio", `Nagrywanie: ${this._isRecording ? 'Włączone' : 'Wyłączone'}`);
        if (this._proc) this._play();
    }

    destroy() {
        this._stop();
        super.destroy();
    }
});

export default class SdrRadioExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._indicator = new SDRIndicator(this._settings, this);
        Main.panel.addToStatusArea(this.uuid, this._indicator);
    }

    disable() {
        if (this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }
        this._settings = null;
    }
}
