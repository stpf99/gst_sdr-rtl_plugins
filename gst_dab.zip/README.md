# gst-dab-open — otwarty DAB/DAB+ dla GStreamera

Element `dabplus` dekoduje DAB/DAB+ z IQ **bez zamkniętych `.so`** (bez libdabsdr).

## Architektura

```
sdrsrc / rtl_tcp  →  IQ F32LE @ 2.048 MHz
                         │
                    dabplus (ten plugin)
                         │
              ┌──────────┼──────────┐
              │ OFDM_Demod (ofdm_core)
              │   soft bits
              ▼
              BasicRadio (basic_radio + dab_core)
              │  FIC → lista stacji
              │  MSC → AAC/MP2 → PCM
              ▼
         audio/x-raw S16LE
```

Źródła OFDM/DAB: [williamyang98/DAB-Radio](https://github.com/williamyang98/DAB-Radio) (MIT).

## Zależności systemowe (AerynOS / Fedora / Ubuntu)

```bash
# Ubuntu/Debian
sudo apt install \
  build-essential meson ninja-build pkg-config \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  libfftw3-dev libfmt-dev libfaad-dev libmpg123-dev

# albo odpowiedniki w pacmanie / eopkg
```

## Pobranie dekodera Viterbiego (submoduł DAB-Radio)

W drzewie `dab-radio/` brakuje `vendor/viterbi_decoder` (git submodule). Pobierz:

```bash
cd gst-dab-open
mkdir -p dab-radio/vendor
git clone --depth 1 \
  https://github.com/williamyang98/ViterbiDecoderCpp.git \
  dab-radio/vendor/viterbi_decoder
```

Dodaj include do `meson.build` (już wskazujemy `dab-radio/src`; dołóż):

```meson
inc = include_directories(
  ...
  'dab-radio/vendor/viterbi_decoder/include',  # dostosuj do layoutu repo
)
```

## Budowa

```bash
cd gst-dab-open
meson setup builddir --prefix=/usr
ninja -C builddir
sudo ninja -C builddir install
# albo bez instalacji:
export GST_PLUGIN_PATH=$PWD/builddir
```

## Pipeline

```bash
gst-launch-1.0 -v \
  sdrsrc mode=tcp host=192.168.1.1 port=1234 \
    frequency=216928000 sample-rate=2048000 gain=7.1 \
  ! queue max-size-buffers=0 max-size-bytes=0 max-size-time=200000000 leaky=downstream \
  ! dabplus channel=11A auto-select=true \
  ! audioconvert ! audioresample \
  ! autoaudiosink sync=false
```

Właściwości `dabplus`:
- `frequency` — Hz (opcjonalne, informacyjne; retune robi źródło)
- `channel` — np. `"11A"`
- `auto-select` — pierwsza stacja audio
- `current-sid` — ręczny SId
- `threads` — wątki OFDM (0 = auto)
- `sync-level` (RO) — liczba zdekodowanych ramek OFDM
- `num-services` (RO)

Sygnały: `sync-changed`, `services-changed`.

## Status

- Element GStreamer: **szkielet produkcyjny** (chain, state, audio caps, auto-select).
- Rdzenie: skopiowane z DAB-Radio (`ofdm_core`, `dab_core`, `basic_radio`).
- Do dokończenia u Ciebie: submoduł Viterbi + ewentualne poprawki ścieżek include / `fmt` / `faad` pod AerynOS.
- Wybór konkretnej stacji po SId (MSC runner) — uproszczony auto-select; pełne mapowanie SId→subchannel można dociągnąć z `basic_radio` API.

## Dlaczego nie libdabsdr

`libdabsdr` to zamknięta binarka AbracaDABra. Przy działającym IQ pull **zero** powiadomień sync — bez źródeł nie da się zdiagnozować skali/count/ABI. Otwarty OFDM pozwala logować stan synchronizacji (`OFDM_Demod::GetState()`).
